/*
Escreva um programa que dados um inteiro n e um caractere ch, solicite que o usuário informe npalavras 
que começam com a letra ch. Se o usuário informar alguma palavra  que  não  comece  com  a  letra ch,  
o  programa  deve  exibir  uma  mensagem informando que a palavra não começa com a letra ch. 
No final o programa deve exibir as npalavras digitadas pelo usuário que começam com a letra ch.
*/
//Observações do exercicio 4
import java.util.Scanner;
import java.io.IOException;

...
public static void main (String[] args) throws Exception{

	...
	int n;
	System.out.print("Digite um valor inteiro: ");
	...
    System.out.print("Digite uma letra: ");
	char c = (char)System.in.read();
	char c1;
	c1 = Character.toLowerCase(c);
	
	String[] palavrasComALetra = new String[n];
	
	//loop para ler as palavras
	int i=0, ind=0;
	while(i<n){
	
		 //usar um objeto entrada
		 //converter a palavra para letras minusculas
	
	     //verificar se a palavra começa com a letra
		 caractereInicial = palavra.charAt(0);
		 if (caractereInicial == c1){
			palavrasComALetra[ind]=palavra;
			ind=ind+1;
		 }
	
	i=i+1;
	}
	
	
	
	
	
	
}