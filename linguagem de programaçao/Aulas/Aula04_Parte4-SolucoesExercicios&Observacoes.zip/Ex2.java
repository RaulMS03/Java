/*
Crie um programa para ler o primeiro nome de uma pessoa e contar quantas vogais esse nome possui.
*/
import java.util.Scanner;
public class Ex2{
	public static void main(String[] args){
				
		Scanner entrada = new Scanner(System.in);
		System.out.print("Digite seu nome: ");
		String nome = entrada.next(); //o next() captura apenas a primeira palavra da String
		String minusculas = nome.toLowerCase();
		
		//Sandra Bianca Henriques Geroldo
		//0123456789...
		
		int i=0, conta=0;
		while (i<minusculas.length()){
			if(minusculas.charAt(i)=='a' || minusculas.charAt(i)=='e' || minusculas.charAt(i)=='i' || minusculas.charAt(i)=='o' || minusculas.charAt(i)=='u'){
				conta=conta+1;
			}
		i=i+1;	
		}
		System.out.println("\nO nome "+nome+" possui "+conta+" vogais");
		System.out.println("\nNome em letras minusculas: "+minusculas); 
		
	}
}