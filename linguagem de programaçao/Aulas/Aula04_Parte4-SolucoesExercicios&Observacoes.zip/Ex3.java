/*Escreva um programa que leia uma string e substitua todos os caracteres ‘a’ da string lida por ‘*’. 
Informe na tela quantos caracteres foram retirados. 
*/
import java.util.Scanner;
public class Ex3{
	public static void main(String[] args){
		
		Scanner entra = new Scanner(System.in);
		System.out.print("Digite uma frase: ");
		String frase = entra.nextLine();
		frase.toLowerCase();
		String novo;
		
		int i=0, conta=0;
		while(i<frase.length()){
			if(frase.charAt(i)=='a'){
			   conta=conta+1;
			   //frase.setCharAt(i,"*");
			}
		i=i+1;
		}
		novo=frase.replace("a","*");
		System.out.println("\nFrase de entrada: "+frase);
		System.out.println("Frase alterada  : "+novo);
		System.out.println("Quantidade de letras a(s) substituidas: "+conta);
	}
}