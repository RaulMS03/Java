import java.util.Scanner;
public class ContaMaiusculas{
  public static void main(String[] args){
	  
	Scanner entra = new Scanner(System.in); 
	System.out.print("Digite uma frase: ");
    String frase = entra.nextLine();
    int maiusculas = 0,espacos=0;
     
    for(int i = 0; i < frase.length(); i++){
        Character caractere = frase.charAt(i);
        if(Character.isUpperCase(caractere)){
            maiusculas++;
        }
    }            
    if(maiusculas!=0)
       System.out.println("A string possui "+maiusculas+" letras maiusculas");
    else
       System.out.println("A string NAO possui letras maiusculas");   
  }
} 